﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Attestation
{
    /// <summary>
    /// Логика взаимодействия для Auth.xaml
    /// </summary>
    public partial class Auth : Page
    {
        public Auth()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(!String.IsNullOrWhiteSpace(Login.Text))
            {
                if(!String.IsNullOrWhiteSpace(Password.Password))
                {
                    var user = AttestationEntities1.GetContext().Users.Where(p => p.Login == Login.Text).Where(p => p.Password==Password.Password).FirstOrDefault();

                    if(user !=null)
                    {
                        UserInfo.user_id = user.user_ID;
                        switch(user.Role)
                        {
                            case "Студент":
                                MessageBox.Show("Вы вошли как Студент");
                                Manager.MainFrame.Navigate(new StudentsPage());
                                break;

                            case "Преподаватель":
                                MessageBox.Show("Вы вошли как Преподаватель");
                                Manager.MainFrame.Navigate(new TeachersPage());
                                break;

                            case "Администратор":
                                MessageBox.Show("Вы вошли как Администратор");
                                Manager.MainFrame.Navigate(new AdminPage());
                                break;
                            default:
                                break;
                        }
                    }

                    else
                    {
                        MessageBox.Show("«Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");
                        Password.Password = "";
                    }
                }

                else
                {
                    MessageBox.Show("Введите пароль");
                }
            }
                else
                {
                    MessageBox.Show("введите логин");
                }
            }
        }


    }
