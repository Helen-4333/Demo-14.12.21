﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Attestation
{
    /// <summary>
    /// Логика взаимодействия для StudentsPage.xaml
    /// </summary>
    public partial class StudentsPage : Page
    {
        public StudentsPage()
        {
            InitializeComponent();
            loadData();
            
        }

        private void loadData()
        {
            var data = AttestationEntities1.GetContext().Students.Where(p => p.student_ID == UserInfo.user_id).FirstOrDefault();

            FIO.Text = data.Surname + " " + data.Name + " " + data.MiddleName;
            specialization.Text = data.Groups.Group;

            var desciplina = AttestationEntities1.GetContext().Groups.Where(p => p.group_ID == data.group_ID).FirstOrDefault().Subjects.ToList();

            disciplina.ItemsSource = Title;
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new AttestationPage());
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new Auth());
        }
    }
}
