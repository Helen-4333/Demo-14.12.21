﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Attestation
{
    static class UserInfo
    {
        public static int user_id { get; set; }
    }
}
